package by.epam.lab.testing.bean;

public class ShowSubjectRequest extends Request{

	
	
}
