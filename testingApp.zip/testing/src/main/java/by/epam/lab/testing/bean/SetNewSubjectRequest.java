package by.epam.lab.testing.bean;

public class SetNewSubjectRequest extends Request {

	private String subjectName;

	public String getSubjectName() {
		return subjectName;
	}

	public void setSubjectName(String subjectName) {
		this.subjectName = subjectName;
	}

}
