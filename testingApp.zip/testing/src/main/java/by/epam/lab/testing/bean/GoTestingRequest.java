package by.epam.lab.testing.bean;

public class GoTestingRequest extends Request{

	private String subjectId;

	public String getSubjectId() {
		return subjectId;
	}

	public void setSubjectId(String subjectId) {
		this.subjectId = subjectId;
	}
	
}
